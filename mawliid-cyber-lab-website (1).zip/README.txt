MAWLIID SHEIKH CYBER LAB

Upload BOTH files to the root of your GitHub repository:
- index.html
- mawliid-photo.jpg

On GitHub: Add file > Upload files. Select both files. If asked, replace the old index.html. Commit to the main branch. Wait for GitHub Pages to rebuild, then refresh your website.

The terminal and password checker are browser-only educational demos. The password checker does not send or save the sample you type.
